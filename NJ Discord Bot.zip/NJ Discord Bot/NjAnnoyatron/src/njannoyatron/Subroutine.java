/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package njannoyatron;

import java.util.ArrayList;
import java.util.Random;
import java.util.StringTokenizer;

/**
 *
 * @author James
 */
public class Subroutine {
    
    public static final Random rand = new Random();
    
    /**
     * Choose one of the provided options and send it back.
     * 
     * @param options Set of options to choose from.
     * @return The selected option.
     */
    public String choose(StringTokenizer options){
        
        ArrayList<String> opts = new ArrayList();
        
        if (!options.hasMoreTokens()){
            
            return "You forgot the options mate.";
        }
        
        while (options.hasMoreTokens()){
            
            opts.add(options.nextToken());
        }
        
        rand.nextInt();
        
        return opts.get(rand.nextInt(opts.size()));
    }
    
    /**
     * Pauses the thread for the settings amount of time.
     * @param settings Strings containing the users time and message for the reminder.
     * @return The reminder message, if any.
     */
    public synchronized String reminder(StringTokenizer settings){
        
        String str = null, timeStr = null;
        char unit = ' ';
        double time = 0;
        
        str = settings.nextToken();
        
        if (str == null){
            
            return "Forget to write what you wanted?";
        }
        else if (str.length() < 2){
            
            return "Give me a time in #u";
        }
        
        timeStr = str.substring(0, str.length() - 1); // Get time value from the string
        try { time = Double.parseDouble(timeStr); }
        catch (Exception e){ return "I didn't get the time you gave me..."; }
        
        unit = str.charAt(str.length() - 1);
        
        if (unit != 's' && unit != 'm' && unit != 'h'){
            
            return "Unit must be s m or h.";
        }
        
        if (unit == 's'){
            
            time = time * 1000;
        }
        else if (unit == 'm'){
            
            time = time * 60 * 1000;
        }
        else if (unit == 'h'){
            
            time = time * 60 * 60 * 1000;
        }
        
        try { this.wait((long)time); }
        catch (Exception e){}
        
        str = "";
        
        if (settings.hasMoreTokens()){
            
            while (settings.hasMoreTokens()) {
                
                str = str + settings.nextToken() + " ";
            }
        }
        else {
            
            str = "Hey go do your shit!";
        }
        
        return str;
    }
    
    /**
     * Takes a sided die and returns a single roll.
     * 
     * @param d Sides of the dice.
     * @return single roll of the die.
     */
    public String dice(int d){
        
        int roll = 0;
        
        if (d > 0 && d < 2147483647){
            
            roll = rand.nextInt(d) + 1;
            
            return " rolled a " + roll + " on a d-" + d;
        }
            
        return " shut up you fat fuck that dice doesnt exist.";
    }
    
    /**
     * Takes rock paper or scissors and generates a response.
     * 
     * @param userChoice the selection from the user.
     * @return The result of a random choice against the user's.
     */
    public String rps(String userChoice){
        
        int roll = rand.nextInt(3);
        
        /* 0 = paper, 1 = rock, 2 = scissors */
        if (roll == 0 && userChoice.equals("rock")){
            
            return "Paper, I win!";
        }
        if (roll == 0 && userChoice.equals("paper")){
            
            return "Paper, tie mothafucka!";
        }
        else if (roll == 0){
            
            return "Paper, I lose...";
        }
        if (roll == 1 && userChoice.equals("scissors")){
            
            return "Rock, I win!";
        }
        if (roll == 1 && userChoice.equals("rock")){
            
            return "rock, tie muthafucka!";
        }
        else if (roll == 1){
            
            return "Rock, I lose...";
        }
        if (roll == 2 && userChoice.equals("paper")){
            
            return "Scissors, I win!";
        }
        if (roll == 2 && userChoice.equals("scissors")){
            
            return "Scissors, tie muthafucka!";
        }
        
        return "Scissors, I lose...";
    }
    
    public String joke(){
        
        return Jokes.jokes[rand.nextInt(Jokes.jokes.length)];
    }
}
