/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package njannoyatron;

/**
 *
 * @author James
 */
public class Jokes {
    
    public static final String[] jokes = new String[]{
        
        "What's 12 inches long and hangs in front of an asshole?\n"
            + "Donald Trump's tie.",
        "What do you call a Jewish Pokemon trainer?\n"
            + "Ash.",
        "What gets easier to pick up the heavier it gets?\n"
            + "Women.",
        "When is a car not a car?\n"
            + "When it turns into a driveway.",
        "School is like a dick...\n"
            + "It's long and hard, unless you're Asian.",
        "A doctor tested a man if he was gay.\n"
            + "He passed with flying colours.",
        "What did the doctor say to the midget in his waiting room?\n"
            + "You're just going to have to be a little patient.",
        "If I had a dollar for every woman that thought I was ugly,\n"
            + "they wouldn't think I was ugly.",
        "Why is the bottom of the ocean black?\n"
            + "Black people can't swim.",
        "I watched porn last night but couldn't get into the plot.\n"
            + "There were just too many holes.",
        "I was thinking of becoming a banker.\n"
            + "But I lost interest.",
        "I was going to make a joke about vaginas,\n"
            + "but you'll never get it.",
        "How do you make a kleenex dance?\n"
            + "Put a little boogie in it.",
        "What's Forrest Gump's password?\n"
            + "1forrest1.",
        "It's hard to explain things to kleptomaniacs.\n"
            + "They always take things literally.",
        "What is Bruce Lee's favourite drink?\n"
            + "Watahhhhhhhhhh.",
        "So this guy with a premature ejaculation problem comes out of nowhere...",
        "Did you hear about the Mexican train killer?\n"
            + "They say he had loco motives.",
        "Why can't you hear a pterodactyl go to the washroom?\n"
            + "Because the P is silent.",
        "Why does Snoop Dogg carry an umbrella?\n"
            + "Fo'drizzle.",
        "Why was 6 afraid of 7?\n"
            + "Because 7 was a well known six offender.",
        "Know what the best part of Switzerland is?\n"
            + "Well I'm not sure but the flag is a big plus!",
        "Why can't a bike stand on its own?\n"
            + "Because it's two tired.",
        "Why didn't the lifegaurd save the hippie?\n"
            + "Because he was too far out man.",
        "What do you call a big pile of kittens?\n"
            + "A meowntain.",
        "When you get a blatter infection,\n"
            + "urine trouble!",
        "How did the hipster burn his tongue?\n"
            + "He drank his coffee before it was cool.",
        "Dry erase boards are remarkable!",
        "Dwarfs and midgets have very little in common.",
        "How do you make Holy water?\n"
            + "Boil the hell out of it.",
        "What does a sign on an out of business brothel say?\n"
            + "Beat it, we're closed.",
        "Why was the guitar teacher arrested?\n"
            + "For fingering a minor.",
        "Why does Santa Claus have such a big sack?\n"
            + "He only comes once a year.",
        "Why does Dr. Pepper come in a bottle?\n"
            + "His wife died.",
        "You know my favourite part of gardening?\n"
            + "Getting down with your hoes!",
        "What do you call the useless piece of skin on a penis?\n"
            + "The man.",
        "What do you call someone who refuses to fart in public?\n"
            + "A private tutor.",
        "Best part of the 21st century,\n"
            + "Deleting history is more important than making it.",
        "Where's the best place to hide a body?\n"
            + "Page 2 of Google.",
        "I love pressing F5.\n"
            + "It's so refreshing.",
        "How many IT guys does it take to screw in a lightbulb?\n"
            + "None. That's a hardware problem.",
        "Knock knock. Who's there?\n"
            + "...Java.",
        "I would love to change the world,\n"
            + "but they won't give me the source code.",
        "How do you keep a programmer in the shower all day?\n"
            + "Give him shampoo that says lather rinse repeat.",
        "Someone dropped a laptop in the ocean the other day.\n"
            + "Now there's a Dell rolling in the deep."
    };
}
