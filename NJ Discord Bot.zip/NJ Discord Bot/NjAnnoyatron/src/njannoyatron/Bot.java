/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package njannoyatron;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.util.ArrayList;
import java.util.StringTokenizer;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import net.dv8tion.jda.*;
import net.dv8tion.jda.entities.Channel;
import net.dv8tion.jda.entities.Message;
import net.dv8tion.jda.entities.MessageChannel;
import net.dv8tion.jda.entities.TextChannel;
import net.dv8tion.jda.entities.User;
import net.dv8tion.jda.entities.VoiceChannel;
import net.dv8tion.jda.entities.impl.JDAImpl;
import net.dv8tion.jda.entities.impl.MessageImpl;
import net.dv8tion.jda.events.message.*;
import net.dv8tion.jda.events.user.UserOnlineStatusUpdateEvent;
import net.dv8tion.jda.events.voice.VoiceJoinEvent;
import net.dv8tion.jda.hooks.ListenerAdapter;

/**
 *
 * @author James
 */
public class Bot extends ListenerAdapter implements ActionListener {

    
    /**
     * Class used to handle multiple messages at the same time.
     * 
     * Whenever a message is received it will spawn a thread to
     * handle the message. This allows for reminders to wait 
     * a set amount of time while the bot handles other events.
     */
    private class ThreadedMessageHandler extends Thread {
        
        private MessageReceivedEvent event;
        
        ThreadedMessageHandler (MessageReceivedEvent e){
            
            super();
            
            event = e;
        }
        
        @Override
        public void run(){
            
            StringTokenizer tokens;
            MessageChannel ch = event.getChannel();
            String msg = event.getMessage().getContent();
            String cur;

            if (msg != null && msg.length() > 0 && msg.charAt(0) == '!') {

                msg = msg.substring(1);

                tokens = new StringTokenizer(msg, " ");

                cur = tokens.nextToken();
                
                /* Change settings */
                if (cur.equalsIgnoreCase("set")){
                    
                    changeSettings(tokens);
                }
                /* Choose an option from the list */
                else if (cur.equalsIgnoreCase("choose")){
                    
                    sendTTSMsg(ch, subs.choose(tokens));
                }
                /* Set a short period reminder */
                else if (cur.equalsIgnoreCase("reminder")) {

                    sendTTSMsg(ch, subs.reminder(tokens));
                }
                /* Dice roller */
                else if (cur.equalsIgnoreCase("roll")) {

                    cur = tokens.nextToken();

                    if (cur == null) {

                        msg = subs.dice(6);
                    }
                    else {

                        int d;

                        try { d = Integer.parseInt(cur); }
                        catch (Exception e) { d = 0; }

                        msg = subs.dice(d);
                    }

                    sendTTSMsg(ch, event.getAuthor().getUsername() + msg);
                }
                /* Rock paper scissors */
                else if (msg.equalsIgnoreCase("rock")
                        || msg.equalsIgnoreCase("paper") ||
                        msg.equalsIgnoreCase("scissors")) {

                    sendTTSMsg(ch, subs.rps(msg));
                }
                /* Tell a joke */
                else if (msg.equalsIgnoreCase("joke")){
                    
                    sendTTSMsg(ch, subs.joke());
                }
                /* Default */
                else {

                    sendTTSMsg(ch, event.getAuthor().getUsername() + ", uhh, u wut m8?");
                }
            }

            if (event.getMessage().getContent().equalsIgnoreCase("dank")) {

                sendTTSMsg(ch, "Shut up nirusan and suck my dick.\n JK");
            }
        }
    }
    
    
    /* Bot Variables */
    private JDA jda;
    private Subroutine subs;
    private SystemTray tray;
    private TrayIcon trayIco;
    
        /* Settings */
    private boolean silentMode;
    private String helloImage;
    
        /* Support */
    private ArrayList<User> recentOnline;
    
    
    Bot(JDA j){
        
        super();
        
        jda = j;
        jda.addEventListener(this);
        
        subs = new Subroutine();
        
        silentMode = false;
        helloImage = "http://i.imgur.com/YwN4zAD.gif";
        
        recentOnline = new ArrayList();
        
        /* Set up system tray icon menu */
        if (SystemTray.isSupported()){
            
            tray = SystemTray.getSystemTray();
            try{
                Image img = new ImageIcon("image/njboticon.png").getImage();
                trayIco = new TrayIcon(img);
            }
            catch (Exception e){
                
                System.err.println("Error opening image to create tray icon.");
            }
            trayIco.setToolTip("Discord bot is running.");
            trayIco.setImageAutoSize(true);
            trayIco.addActionListener(this);
            
            PopupMenu pop = new PopupMenu();
            
            MenuItem shut = new MenuItem("Shutdown");
            shut.addActionListener(this);
            
            pop.add(shut);
            trayIco.setPopupMenu(pop);
            
            try { tray.add(trayIco); }
            catch (Exception e){ System.err.println("Could not add icon to tray."); }
            
            load();
        }
    }
    
    /**
     * Load settings from the previous execution.
    */
    private void load(){
        
        try {
            
            BufferedReader read = new BufferedReader(new FileReader("jeebes.ini"));
            
            while (read.ready()){
                
                StringTokenizer tokens = new StringTokenizer(read.readLine(), "=");
                
                if (tokens.nextToken().equals("WelcomeImage")){
                    
                    helloImage = tokens.nextToken();
                }
                else if (tokens.nextToken().equals("SilentMode")){
                    
                    silentMode = Boolean.getBoolean(tokens.nextToken());
                }
            }
            
        } catch (Exception e){}
    }
    
    /**
     * Save current settings for next execution.
     */
    private void save(){
        
        try {
            
            PrintWriter write = new PrintWriter(new File("jeebes.ini"));
            
            write.println("WelcomeImage=" + helloImage);
            write.println("SilentMode=" + silentMode);
            
            
            write.close();
            
        } catch (Exception e){}
    }
    
    private void changeSettings(StringTokenizer sets){
        
        String tok;
        
        while (sets.hasMoreTokens()){
            
            tok = sets.nextToken();
            
            /* Eliminate seperaters if another setting */
            if (tok.equals("|") && sets.hasMoreTokens()){
                
                tok = sets.nextToken();
            }
            
            /* Silent mode */
            if (tok.equalsIgnoreCase("silent")){
                
                tok = sets.nextToken();
                
                if (tok != null && tok.equalsIgnoreCase("true")){
                    
                    silentMode = true;
                }
                else if (tok != null && tok.equalsIgnoreCase("false")){
                    
                    silentMode = false;
                }
            }
            
            else if (tok.equalsIgnoreCase("hello")){
                
                tok = sets.nextToken();
                
                if (tok.startsWith("http://") || tok.startsWith("https://")){
                    
                    helloImage = tok;
                }
            }
        }
    }
    
    @Override
    public synchronized void onUserOnlineStatusUpdate(UserOnlineStatusUpdateEvent event){
        
        // Add user to a queue to be said hello to if they join voice channel
        if (!recentOnline.contains(event.getUser())){
            
            recentOnline.add(event.getUser());
            
            // Allow discord to load so user hears it
            try { this.wait(4400); }
            catch (Exception e){}
        }
    }
    
    @Override
    public void onVoiceJoin(VoiceJoinEvent event){
        
        TextChannel ch = event.getJDA().getTextChannels().get(0);
        
        /* Say hellow to a user if they recently came online and joined */
        if (recentOnline.contains(event.getUser())
            && !event.getChannel().getName().equals("Waifu Hawt Zown")
            ){
            
            recentOnline.remove(event.getUser());
            
            sendTTSMsg(ch, "Welcome " + event.getUser().getUsername());
            ch.sendMessage(helloImage);
        }
    }
    
    @Override
    public void onMessageReceived(MessageReceivedEvent event) {
        
        ThreadedMessageHandler tmh = new ThreadedMessageHandler(event);
        
        tmh.start();
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        
        if (e.getActionCommand().equals("Shutdown")){
            
            save();
            
            jda.shutdown();
            System.exit(0);
        }
    }
    
    /**
     * Sends the given message to the specific channel in TTS.
     * 
     * @param ch Channel to send the message.
     * @param msg Message to send to the channel.
     * @return The message object created.
     */
    public synchronized Message sendTTSMsg(MessageChannel ch, String msg){
        
        return ch.sendMessage(new MessageImpl("A message from NJA", new JDAImpl(false))
                .setTTS(!silentMode).setContent(msg)
                );
    }
}
